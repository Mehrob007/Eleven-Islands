const DeliveryWidget = () => (
    <iframe
        src="https://delivery.yandex.ru/widget/pvz?lang=ru"
        width="100%" height="500px"
        frameBorder="0">
    </iframe>
);

export default DeliveryWidget;